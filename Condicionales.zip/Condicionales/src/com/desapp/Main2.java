package com.desapp;

public class Main2 {

	public static void main(String[] args) {
		// Estructuras condicionales
		
		// Estructura condicional en cascada
		
		/**
		 * Una cadena de supermercados ha puesto en oferta la venta al por 
		 * mayor de un producto, se da un descuento del 15% cuando se compran 
		 * más de 2 docenas y 10% en caso contrario. Además por la compra de más de 
		 * 2 docenas se obsequia una unidad del producto por cada docena de más. 
		 * Diseñe un algoritmo que determine el monto de la compra, el monto del descuento, 
		 * el monto a pagar y el número de unidades de obsequio por la compra de cierta 
		 * cantidad de docenas del producto.
		 */
		
	}

}
